# expect: B105@2
password = "SuperSecret123"


def connect(db):
    return db.login("admin", password)
