# expect: B608@4
def get_user(cursor, username: str):
    cursor.execute(
        "SELECT * FROM users WHERE name = '%s'" % username
    )
    return cursor.fetchall()
