# expect: B311@6
import random


def reset_token() -> str:
    return str(random.randint(100000, 999999))
