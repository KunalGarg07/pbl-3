# expect: B301@6
import pickle


def load_session(blob: bytes):
    return pickle.loads(blob)
