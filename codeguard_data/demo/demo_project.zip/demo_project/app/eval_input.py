# expect: B307@3
user_input = input("Enter expression: ")
result = eval(user_input)
print(result)
