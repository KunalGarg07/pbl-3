# expect: B605@6
import os


def remove(path: str) -> None:
    os.system("rm -rf " + path)
