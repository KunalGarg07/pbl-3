# expect: B501@6
import requests


def fetch(url: str) -> str:
    return requests.get(url, verify=False, timeout=10).text
