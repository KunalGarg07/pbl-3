# expect: B306@6
import tempfile


def scratch_path() -> str:
    return tempfile.mktemp()
