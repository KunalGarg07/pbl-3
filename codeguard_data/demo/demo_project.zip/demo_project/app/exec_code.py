# expect: B102@4
def run_plugin(code: str) -> None:
    namespace = {}
    exec(code, namespace)
