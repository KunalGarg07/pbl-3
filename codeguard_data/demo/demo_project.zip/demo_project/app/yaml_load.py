# expect: B506@6
import yaml


def read_config(text: str):
    return yaml.load(text, Loader=yaml.Loader)
