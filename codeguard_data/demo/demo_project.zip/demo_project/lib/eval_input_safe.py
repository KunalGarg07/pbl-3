# must-not: B307
import ast

user_input = input("Enter a literal: ")
result = ast.literal_eval(user_input)
print(result)
