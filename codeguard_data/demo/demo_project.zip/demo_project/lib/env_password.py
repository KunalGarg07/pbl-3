# must-not: B105
import os

password = os.environ.get("DB_PASSWORD")
