# must-not: B301 B403
import json


def load_session(blob: bytes):
    return json.loads(blob)
