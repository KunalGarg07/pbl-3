# must-not: B306
import tempfile


def scratch_file():
    return tempfile.NamedTemporaryFile(delete=False)
