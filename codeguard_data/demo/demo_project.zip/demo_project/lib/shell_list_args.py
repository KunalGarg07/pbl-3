# must-not: B602 B605
import subprocess


def ping(host: str) -> str:
    return subprocess.run(["ping", "-c", "1", host], capture_output=True, text=True, check=False).stdout
