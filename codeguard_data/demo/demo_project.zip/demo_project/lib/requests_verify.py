# must-not: B501
import requests


def fetch(url: str) -> str:
    return requests.get(url, timeout=10).text
