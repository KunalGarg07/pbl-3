# must-not: B506
import yaml


def read_config(text: str):
    return yaml.safe_load(text)
