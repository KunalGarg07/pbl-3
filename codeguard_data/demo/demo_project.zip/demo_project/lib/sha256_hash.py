# must-not: B324 B303
import hashlib


def fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
