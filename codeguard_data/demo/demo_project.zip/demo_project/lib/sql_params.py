# must-not: B608
def get_user(cursor, username: str):
    cursor.execute("SELECT * FROM users WHERE name = ?", (username,))
    return cursor.fetchall()
