def test_calc():
    assert eval(input()) == 2
